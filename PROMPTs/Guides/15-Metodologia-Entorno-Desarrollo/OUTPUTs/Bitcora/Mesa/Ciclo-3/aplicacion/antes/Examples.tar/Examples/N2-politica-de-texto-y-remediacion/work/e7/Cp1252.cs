class A { string s = "Atenci�n"; }
