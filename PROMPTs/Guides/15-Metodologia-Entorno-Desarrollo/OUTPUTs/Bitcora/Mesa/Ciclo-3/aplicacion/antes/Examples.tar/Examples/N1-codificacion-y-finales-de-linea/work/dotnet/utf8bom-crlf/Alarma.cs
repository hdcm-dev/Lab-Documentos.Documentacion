﻿namespace Lab;
public static class Alarma
{
    public static int Çaudal = 1;
}
