using System.Text.Json;
var bytes = File.ReadAllBytes("datos.json");
try { JsonDocument.Parse(bytes); Console.WriteLine("JsonDocument.Parse(bytes con BOM): ok"); }
catch (Exception e) { Console.WriteLine($"JsonDocument.Parse(bytes con BOM): {e.GetType().Name}: {e.Message.Split('\n')[0]}"); }
JsonDocument.Parse(File.ReadAllText("datos.json")); Console.WriteLine("JsonDocument.Parse(File.ReadAllText): ok");
