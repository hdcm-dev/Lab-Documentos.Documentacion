namespace Lab;
public static class Alarma
{
    public static int �audal = 1;
}
