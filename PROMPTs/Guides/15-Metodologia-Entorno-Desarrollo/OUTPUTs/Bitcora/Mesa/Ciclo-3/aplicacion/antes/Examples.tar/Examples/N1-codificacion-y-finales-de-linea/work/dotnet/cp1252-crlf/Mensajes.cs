namespace Lab;
public static class Mensajes
{
    public const string Texto = "Atenci�n: se�al recibida en �andubay";
    // Literal crudo multil�nea: sus finales de l�nea son los del archivo
    public const string Bloque = """
        uno
        dos
        """;
}
