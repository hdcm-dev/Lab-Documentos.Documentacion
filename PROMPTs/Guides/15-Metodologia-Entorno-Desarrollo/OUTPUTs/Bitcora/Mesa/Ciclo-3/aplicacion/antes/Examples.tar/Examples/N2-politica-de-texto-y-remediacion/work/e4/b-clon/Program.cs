static int �ltimaLectura() => 42;
System.Console.WriteLine($"Atenci�n {�ltimaLectura()}");
