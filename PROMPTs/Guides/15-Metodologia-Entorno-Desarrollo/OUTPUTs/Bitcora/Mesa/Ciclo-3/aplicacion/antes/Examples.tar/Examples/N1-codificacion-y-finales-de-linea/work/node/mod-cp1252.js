// literal no ASCII
const texto = "Atenci�n: se�al recibida en �andubay";
const bloque = `uno
dos`;
module.exports = { texto, bloque };
