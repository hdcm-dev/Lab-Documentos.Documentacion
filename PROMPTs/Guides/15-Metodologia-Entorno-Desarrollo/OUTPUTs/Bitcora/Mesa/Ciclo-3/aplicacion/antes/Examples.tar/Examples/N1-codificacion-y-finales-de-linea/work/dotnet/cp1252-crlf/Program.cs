using Lab;
var t = Mensajes.Texto;
System.Console.WriteLine($"Texto  : {t}");
System.Console.WriteLine($"Largo  : {t.Length} (esperado 36)");
System.Console.WriteLine("U+     : " + string.Join(" ", System.Linq.Enumerable.Select(t.Substring(6, 3), c => ((int)c).ToString("X4"))));
System.Console.WriteLine($"Bloque : {Mensajes.Bloque.Length} chars (LF=7, CRLF=8) contieneCR={Mensajes.Bloque.Contains('\r')}");
