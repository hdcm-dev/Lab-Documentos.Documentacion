namespace Heredado;
public static class Sensor
{
    // identificador con letra no ASCII: en cp1252 el compilador en Linux no lo reconoce
    public static int ÚltimaLectura() => 42;
}
