// identificador no ASCII
const a�o = 2026;
module.exports = { a�o };
