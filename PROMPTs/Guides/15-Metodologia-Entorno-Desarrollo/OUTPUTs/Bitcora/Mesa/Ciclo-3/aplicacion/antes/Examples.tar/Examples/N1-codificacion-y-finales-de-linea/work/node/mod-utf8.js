// literal no ASCII
const texto = "Atención: señal recibida en Ñandubay";
const bloque = `uno
dos`;
module.exports = { texto, bloque };
