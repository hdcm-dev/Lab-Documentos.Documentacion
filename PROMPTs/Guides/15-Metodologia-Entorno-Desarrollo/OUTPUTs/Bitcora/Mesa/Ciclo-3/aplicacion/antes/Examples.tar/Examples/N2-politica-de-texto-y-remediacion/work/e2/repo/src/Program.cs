using Heredado;
System.Console.WriteLine($"{Mensajes.Alerta} ({Sensor.ÚltimaLectura()})");
System.Console.WriteLine(Mensajes.Pie);
