﻿class C { }
