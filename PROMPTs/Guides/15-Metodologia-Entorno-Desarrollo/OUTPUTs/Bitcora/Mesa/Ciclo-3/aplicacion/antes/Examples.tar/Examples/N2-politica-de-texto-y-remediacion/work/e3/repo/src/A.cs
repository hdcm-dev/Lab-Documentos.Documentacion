namespace App;
public static class A { public const string S = "Atención"; }
