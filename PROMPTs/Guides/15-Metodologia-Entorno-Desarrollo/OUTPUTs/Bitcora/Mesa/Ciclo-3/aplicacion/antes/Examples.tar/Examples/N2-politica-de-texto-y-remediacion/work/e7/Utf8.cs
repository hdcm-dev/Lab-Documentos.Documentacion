class B { string s = "Atención"; }
