﻿namespace Lab;
public static class Mensajes
{
    public const string Texto = "Atención: señal recibida en Ñandubay";
    // Literal crudo multilínea: sus finales de línea son los del archivo
    public const string Bloque = """
        uno
        dos
        """;
}
