﻿export const texto = "Atención: señal recibida en Ñandubay";
