namespace Heredado;
public static class Util { public static int Doble(int x) => x * 2; }
