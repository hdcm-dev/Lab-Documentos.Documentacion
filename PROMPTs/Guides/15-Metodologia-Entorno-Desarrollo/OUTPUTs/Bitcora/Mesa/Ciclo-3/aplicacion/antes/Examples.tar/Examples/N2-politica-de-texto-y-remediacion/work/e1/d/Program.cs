var s = @"a
b";
System.Console.WriteLine($"largo={s.Length} bytes={System.BitConverter.ToString(System.Text.Encoding.UTF8.GetBytes(s))}");
