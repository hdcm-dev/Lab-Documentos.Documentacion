texto = "Atención: señal recibida en Ñandubay"
bloque = """uno
dos"""
print(repr(texto), len(texto), repr(bloque))
