namespace Heredado;
public static class Mensajes
{
    public const string Alerta = "Atención: lectura fuera de rango";
    public const string Pie = "Señal recibida y registrada";
}
