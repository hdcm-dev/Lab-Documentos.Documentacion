texto = "Atenci�n: se�al recibida en �andubay"
bloque = """uno
dos"""
print(repr(texto), len(texto), repr(bloque))
